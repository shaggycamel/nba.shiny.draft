
<!-- README.md is generated from README.Rmd. Please edit that file -->

# `{nba.shiny.draft}`

<!-- badges: start -->

<!-- badges: end -->

## Installation

You can install the development version of `{nba.shiny.draft}` like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Run

You can launch the application by running:

``` r
nba.shiny.draft::run_app()
```

## About

You are reading the doc about version : 0.0.0.9000

This README has been compiled on the

``` r
Sys.time()
#> [1] "2025-10-25 21:49:31 NZDT"
```

Here are the tests results and package coverage:

``` r
devtools::check(quiet = TRUE)
#> ℹ Loading nba.shiny.draft
#> Error: Could not find tools necessary to compile a package
#> Call `pkgbuild::check_build_tools(debug = TRUE)` to diagnose the problem.
```

``` r
covr::package_coverage()
#> Error in loadNamespace(x): there is no package called 'covr'
```
